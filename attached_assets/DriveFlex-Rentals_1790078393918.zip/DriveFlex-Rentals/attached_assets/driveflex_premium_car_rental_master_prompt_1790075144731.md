# MASTER PROMPT — PREMIUM CAR RENTAL MARKETPLACE WEBSITE

## Role

Act as a senior product designer, UX engineer, and production-level Next.js developer.

Build a complete, responsive, premium car-rental marketplace website using the existing Stitch design assets and the requirements in this document.

The result must feel like a **luxury automotive brand**, not a generic travel-booking template.

Core brand message:

> **Premium Cars. Powerful Choices. Simple Booking.**

---

# 1. FIRST: INSPECT THE PROVIDED DESIGN ASSETS

Before changing or generating code:

1. Inspect all files inside:

   `C:\Users\Emaad\Desktop\DriveFlex-assets`

2. Review the Stitch-generated designs, screenshots, layouts, icons, typography, spacing, component patterns, and visual hierarchy.

3. Recreate the visual direction of the Stitch designs as accurately as possible.

4. Do not blindly replace the Stitch design with a generic template.

5. If the Stitch assets and this prompt conflict:
   - Preserve the required route structure and functionality from this prompt.
   - Preserve the Red + Black + Gold visual system defined below.
   - Reuse useful Stitch layout ideas, component patterns, and visual details wherever possible.

6. Inspect the existing codebase before editing it. Identify:
   - Framework and routing structure
   - Existing components
   - Existing styles and Tailwind configuration
   - Existing assets
   - Existing forms and reusable UI
   - Any current functionality that should be preserved

Do not delete or rewrite working code unnecessarily.

---

# 2. PROJECT OBJECTIVE

Create a production-quality frontend for a future car-rental marketplace where users can:

- Browse premium and everyday vehicles
- Search cars by location and dates
- View detailed vehicle information
- Check availability using mock data
- Calculate rental prices
- Start a booking flow
- Register and sign in through a frontend demo flow
- Manage a mock profile
- Contact the company
- Learn about the company
- List a car through a future-facing CTA

The website must be functional on the frontend, but it must not pretend to have a real backend.

---

# 3. REQUIRED TECHNOLOGY

Use:

- Next.js
- React
- TypeScript
- App Router
- Tailwind CSS
- `next/image`
- Reusable React components
- Server Components by default
- Client Components only where interaction is required

Use clean, maintainable, scalable code.

Avoid:

- Unnecessary dependencies
- Duplicate components
- Hardcoded repeated data
- Unstructured page-specific logic
- Unnecessary global state
- Hydration errors
- Console errors
- Unused imports
- Broken links
- Placeholder buttons that do nothing

---

# 4. REQUIRED ROUTES

Implement only the following routes:

```text
/
 /about
 /contact
 /register
 /sign-in
 /profile
 /cars/[slug]
```

Do not create additional routes such as:

- `/explore`
- `/locations`
- `/how-it-works`
- `/dashboard`
- `/checkout`
- `/payment`
- `/bookings`
- `/provider-dashboard`

The booking interaction must happen through the car detail page, modal, drawer, or another appropriate frontend interaction without creating an additional booking route.

---

# 5. VISUAL DESIGN SYSTEM

The entire website must consistently use the following color system.

## Primary Colors

```text
Deep Black:       #0A0A0A
Charcoal:         #151515
Dark Gray:        #1C1C1C
Luxury Red:       #B11226
Bright Red:       #D61F3C
Dark Red:         #7A0C1A
Luxury Gold:      #C9A227
Bright Gold:      #E0B84C
Dark Gold:        #9A7617
Soft White:       #F5F5F5
Muted Gray:       #A3A3A3
Border Gray:      #2A2A2A
```

## Color Usage Rules

Use the approximate visual balance below:

- 60% black and dark surfaces
- 20% red accents and action areas
- 10% gold premium highlights
- 10% white and gray typography

### Black

Use black and charcoal for:

- Main page backgrounds
- Navigation
- Cards
- Sections
- Footer
- Modal backgrounds

### Red

Use red for:

- Primary CTAs
- Booking actions
- Active states
- Important highlights
- Interactive controls
- Error states when appropriate

### Gold

Use gold carefully for:

- Premium labels
- Luxury accents
- Ratings
- Selected borders
- Small decorative details
- Premium vehicle highlights
- Hover accents

Do not overuse gold. It must feel exclusive and refined rather than loud.

### Typography

Use:

- **DM Sans** for headings and major display text
- **Inter** for body text, labels, forms, and UI elements

Typography must have:

- Strong hierarchy
- Clear readability
- Premium spacing
- Appropriate line height
- Responsive font sizes

---

# 6. BRAND AND DESIGN DIRECTION

The design should communicate:

- Premium automotive quality
- Trust
- Confidence
- Performance
- Simplicity
- Modern technology
- Reliable booking
- High-end mobility

Use:

- Strong editorial headings
- Large automotive imagery
- Dark cinematic surfaces
- Sharp but elegant cards
- Subtle borders
- Restrained gradients
- Smooth hover transitions
- Refined micro-interactions
- Strong visual hierarchy

Avoid:

- Generic SaaS styling
- Excessive rounded cards
- Excessive gradients
- Overly bright backgrounds
- Random colors
- Cartoonish UI
- Excessive animations
- Cluttered layouts
- Huge empty spaces
- Cheap-looking stock-template design

The design must feel like a premium automotive company.

---

# 7. HOMEPAGE REQUIREMENTS

The homepage must include the following sections.

## 7.1 Navigation Bar

Include:

- Brand logo/name
- Navigation links
- About
- Contact
- Sign In
- Register
- Profile access when a mock user is signed in
- Responsive mobile navigation

Requirements:

- Sticky or fixed navigation where appropriate
- Strong contrast
- Accessible focus states
- Mobile menu
- Clear active states
- Working navigation links

---

## 7.2 Hero Section

Create a premium hero section with:

- Strong headline
- Supporting description
- Primary CTA
- Secondary CTA
- Automotive imagery
- Search or booking interface
- Dark cinematic background
- Red action elements
- Subtle gold accents

Example direction:

> Find the right car for every journey.

The final copy should feel polished and brand-specific. Do not use generic filler text.

Primary CTA examples:

- Find Cars
- Explore Premium Fleet

Secondary CTA examples:

- List Your Car
- Contact Us

Every CTA must perform a meaningful frontend action.

---

## 7.3 Search and Availability Interface

Create a functional search component containing:

- Pickup location
- Drop-off location
- Pickup date
- Return date
- Optional radius or location preference
- Search button

Validation must include:

- Required location fields
- Valid pickup date
- Return date after pickup date
- No invalid or empty search submission
- Clear inline error messages
- Accessible labels

When the user searches:

1. Validate the input.
2. Filter the centralized mock vehicle data.
3. Display matching vehicles or a clear empty state.
4. Keep the interaction on the homepage.
5. Do not create an `/explore` route.

The results area may scroll into view or update dynamically.

---

## 7.4 Featured and Nearby Vehicles

Display a responsive vehicle grid with at least:

- 8–12 realistic mock vehicles
- Vehicle image
- Brand and model
- Vehicle category
- Price per day
- Location
- Rating
- Availability indicator
- Favorite button
- View Car CTA

Vehicle categories may include:

- Luxury
- SUV
- Sedan
- Sports
- Electric
- Economy

Every vehicle card must:

- Be keyboard accessible
- Have meaningful alt text
- Support hover and focus states
- Link to `/cars/[slug]`
- Use a valid vehicle slug
- Use optimized images with `next/image`

---

## 7.5 Why Choose Us

Include 3–5 benefits such as:

- Verified vehicles
- Transparent pricing
- Flexible booking
- Premium customer support
- Convenient pickup locations

Use clean icons and concise copy.

---

## 7.6 Premium Showcase Section

Create a visually strong section highlighting premium vehicles or luxury experiences.

Use:

- Large imagery
- Dark background
- Gold accents
- Red CTA
- Strong editorial layout
- Responsive design

The section should not feel disconnected from the rest of the site.

---

## 7.7 List Your Car CTA

Add a prominent CTA inviting vehicle owners to participate in the marketplace.

Example:

> Have a car worth sharing?

The CTA may:

- Navigate to `/contact`
- Open a frontend inquiry modal
- Scroll to a contact/inquiry section

Do not create a provider dashboard or actual listing backend.

---

## 7.8 Footer

Include:

- Brand information
- Navigation links
- Contact link
- About link
- Sign-in/register links
- Social placeholders if appropriate
- Copyright text
- Clear visual hierarchy

All footer links must work.

---

# 8. CAR DETAIL PAGE

Route:

```text
/cars/[slug]
```

Each vehicle detail page must include:

- Large vehicle gallery or hero image
- Vehicle name
- Brand
- Category
- Location
- Rating
- Description
- Key specifications
- Seating capacity
- Transmission
- Fuel type
- Mileage or range
- Price per day
- Availability section
- Booking widget
- Provider information
- Reviews
- Related vehicles
- Back navigation

The page must be responsive and visually consistent with the homepage.

---

# 9. BOOKING WIDGET AND FUNCTIONALITY

The booking widget must include:

- Pickup date
- Return date
- Rental duration
- Price per day
- Estimated total price
- Availability status
- Book Now CTA

Implement a reusable utility such as:

```ts
calculateRentalPrice(pricePerDay, pickupDate, returnDate)
```

The calculation must:

- Calculate the rental duration correctly
- Prevent invalid date ranges
- Display a clear price breakdown
- Update immediately when dates change
- Handle missing dates safely

The booking flow must follow this sequence:

## Step 1: Validate Dates

Check:

- Both dates are selected
- Return date is after pickup date
- Selected dates are not unavailable in the mock data

## Step 2: Authentication State

If the user is not signed in:

- Show a clear message
- Provide Sign In and Register actions
- Preserve the booking context when possible

If the user is signed in:

- Show a booking confirmation interface

## Step 3: Confirmation

Display:

- Vehicle name
- Pickup date
- Return date
- Rental duration
- Estimated total
- Confirmation CTA

After confirmation:

- Show a clearly labeled frontend demo confirmation
- Do not claim that a real reservation was created
- Do not process payments
- Do not call a real booking API

Use language such as:

> Demo booking confirmed. This is a frontend preview and does not create a real reservation.

---

# 10. CTA FUNCTIONALITY REQUIREMENTS

Every CTA must have a clear purpose and working behavior.

| CTA | Required Behavior |
|---|---|
| Find Cars | Validate search and display matching mock vehicles |
| View Car | Navigate to `/cars/[slug]` |
| Book Now | Validate dates and open booking flow |
| Sign In | Navigate to `/sign-in` |
| Register | Navigate to `/register` |
| View Premium Fleet | Scroll to or display the relevant fleet section |
| Contact Us | Navigate to `/contact` |
| List Your Car | Navigate to `/contact` or open an inquiry interaction |
| Edit Profile | Enable editable mock profile fields |
| Send Message | Validate and submit the frontend contact form |
| Sign Out | Clear the mock session state |
| Favorite | Toggle favorite state with visible feedback |

Do not leave any major CTA as a decorative button.

---

# 11. SIGN-IN PAGE

Route:

```text
/sign-in
```

Include:

- Email input
- Password input
- Validation
- Submit button
- Register link
- Clear error states
- Loading state
- Success state

This is a frontend demonstration only.

Do not:

- Implement real authentication
- Store real passwords
- Expose sensitive credentials
- Claim that a real account was created

Use a safe mock session approach.

---

# 12. REGISTER PAGE

Route:

```text
/register
```

Include:

- Full name
- Email
- Password
- Confirm password
- Validation
- Submit button
- Sign-in link
- Loading state
- Success state

Validation must include:

- Required fields
- Valid email format
- Password requirements
- Matching passwords
- Clear accessible errors

After successful demo registration:

- Create a mock frontend session
- Redirect or link the user to `/profile`
- Clearly label the flow as a demo

---

# 13. PROFILE PAGE

Route:

```text
/profile
```

Include:

- Mock user information
- Name
- Email
- Profile image or avatar
- Edit Profile action
- Saved/favorite vehicles
- Demo booking history if appropriate
- Sign Out action

Requirements:

- Editable fields should work locally
- Sign Out must clear the mock session
- Do not use real user data
- Do not create a backend account system

If the user is not signed in, show a useful sign-in prompt.

---

# 14. CONTACT PAGE

Route:

```text
/contact
```

Include:

- Contact information
- Contact form
- Name
- Email
- Subject or inquiry category
- Message
- Submit button
- Validation
- Loading state
- Success feedback
- Error feedback

The form must be frontend-only.

Do not claim that an email was actually sent unless a real email backend exists.

Use a message such as:

> Your message has been submitted in this frontend demo.

---

# 15. ABOUT PAGE

Route:

```text
/about
```

Include:

- Company story
- Brand mission
- Marketplace concept
- Trust and safety messaging
- Premium mobility positioning
- CTA to browse cars
- CTA to contact the company

Use polished, realistic content. Avoid meaningless placeholder paragraphs.

---

# 16. MOCK DATA ARCHITECTURE

Centralize all mock data in a dedicated location.

Example structure:

```text
src/
  data/
    vehicles.ts
    reviews.ts
    users.ts
  lib/
    booking.ts
    validation.ts
  components/
    cars/
    booking/
    forms/
    layout/
    ui/
```

Vehicle data should include:

```ts
type Vehicle = {
  id: string
  slug: string
  brand: string
  model: string
  category: string
  location: string
  pricePerDay: number
  rating: number
  reviewCount: number
  seats: number
  transmission: string
  fuelType: string
  description: string
  image: string
  gallery?: string[]
  unavailableDates?: string[]
}
```

Use realistic data and avoid repeated placeholder values.

---

# 17. IMAGE REQUIREMENTS

Use:

- Stitch assets wherever appropriate
- `next/image`
- Optimized image sizing
- Meaningful alt text
- Responsive image behavior

If external imagery is required, use suitable Unsplash automotive images.

Do not:

- Use broken image URLs
- Use random unrelated images
- Use watermarked images
- Use images without alt text
- Create layout shifts unnecessarily

Ensure external image domains are configured correctly if required by Next.js.

---

# 18. RESPONSIVE REQUIREMENTS

Test the interface at:

```text
320px
375px
390px
430px
768px
1024px
1280px
1440px
1920px
```

The layout must support:

- Mobile phones
- Tablets
- Laptops
- Desktop monitors
- Large screens

Check:

- Navigation
- Mobile menu
- Hero layout
- Search form
- Vehicle grids
- Booking widget
- Modals
- Forms
- Footer
- Typography
- Image cropping
- Button sizes

There must be:

- No horizontal overflow
- No clipped text
- No overlapping elements
- No unusable form fields
- No broken mobile layouts

---

# 19. ACCESSIBILITY

Implement:

- Semantic HTML
- Proper heading hierarchy
- Accessible form labels
- Keyboard navigation
- Visible focus states
- Sufficient color contrast
- Descriptive button labels
- Meaningful image alt text
- Accessible modals
- Escape-to-close behavior where appropriate
- Error messages associated with fields
- Accessible mobile navigation

Do not rely only on color to communicate state.

---

# 20. SEO

Add suitable metadata for each route.

Include:

- Page title
- Meta description
- Open Graph metadata where appropriate
- Descriptive headings
- Semantic page structure
- Descriptive URLs
- Proper image alt text

Suggested page themes:

- Premium car rental marketplace
- Browse rental vehicles
- Vehicle details and booking
- About the company
- Contact the company

Do not keyword-stuff the content.

---

# 21. PERFORMANCE AND CODE QUALITY

Ensure:

- Server Components are used by default
- Client Components are limited to interactive areas
- Images are optimized
- Components are reusable
- Data is centralized
- No unnecessary re-renders
- No hydration errors
- No console errors
- No broken imports
- No TypeScript errors
- No unused code
- No layout shift where avoidable

Use clean naming conventions and clear folder organization.

---

# 22. FRONTEND-ONLY LIMITATIONS

This project is a frontend prototype.

Do not implement or pretend to implement:

- Real database integration
- Real authentication
- Real payment processing
- Real booking APIs
- Real reservation creation
- Real provider dashboards
- Real admin systems
- Real email delivery
- Real notification systems

Clearly label demo behavior where necessary.

The code should be structured so that real services can be integrated later without requiring a complete rewrite.

---

# 23. DEVELOPMENT WORKFLOW

Follow this process:

## Phase 1: Inspect

- Inspect the existing codebase
- Inspect all Stitch assets
- Identify existing reusable components
- Review the current design and routing

## Phase 2: Plan

- Plan component structure
- Plan data structure
- Plan page composition
- Identify reusable UI patterns
- Confirm route boundaries

## Phase 3: Implement

- Build the global design system
- Build shared layout components
- Build the homepage
- Build vehicle cards and data
- Build the car detail page
- Build booking functionality
- Build authentication demo pages
- Build profile page
- Build about and contact pages

## Phase 4: Validate

Check:

- All routes load correctly
- All navigation links work
- All major CTAs work
- Search validation works
- Booking calculations work
- Invalid dates are rejected
- Mock authentication state works
- Contact form validation works
- Mobile layout works
- Images load correctly
- No console errors exist
- No hydration errors exist
- No TypeScript errors exist

## Phase 5: Polish

Improve:

- Spacing
- Typography
- Hover states
- Focus states
- Animation timing
- Mobile responsiveness
- Error messages
- Empty states
- Loading states
- Visual consistency

---

# 24. FINAL ACCEPTANCE CRITERIA

The final implementation must:

- Match the Stitch design direction
- Use the Red + Black + Gold color system
- Feel premium and automotive-focused
- Include all required routes
- Include at least 8–12 mock vehicles
- Have working navigation
- Have working CTAs
- Have functional frontend search
- Have functional booking calculations
- Validate booking dates
- Include a mock sign-in/register flow
- Include a functional mock profile
- Include a validated contact form
- Be fully responsive
- Be accessible
- Include SEO metadata
- Use optimized images
- Avoid fake backend claims
- Avoid broken buttons
- Avoid unnecessary routes
- Avoid console and hydration errors

Do not stop after creating static screens.

The website must be a coherent, polished, responsive, frontend-functional car-rental marketplace prototype that is ready for future backend integration.
